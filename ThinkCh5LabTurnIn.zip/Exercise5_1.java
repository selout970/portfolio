// WARNING: This file is auto-generated and any changes to it will be overwritten
import lang.stride.*;

/**
 * Exercise 5.1
 */
public class Exercise5_1
{

    /**
     * Constructor for objects of class Exercise5_1
     */
    public Exercise5_1()
    {
    }

    /**
     * Logical operators can simplify nested conditional statements.  Rewrite this code using a single if statement.
     */
    public void main()
    {
        int x = 5;
        if (x > 0 && x < 10) {
            System.out.println("positive single digit number.");
        }
    }
}
